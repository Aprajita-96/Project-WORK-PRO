package com.stackroute.RecommendationService.controller;


import com.stackroute.RecommendationService.domain.Freelancers;
import com.stackroute.RecommendationService.domain.Projects;
import com.stackroute.RecommendationService.service.FreelancerService;
import com.stackroute.RecommendationService.service.ProjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@RestController
@RequestMapping("/api/v1")
public class RecommendationController {
    private FreelancerService freelancerService;
    private ProjectService projectService;

    @Autowired
    public RecommendationController(FreelancerService freelancerService, ProjectService projectService) {
        this.freelancerService = freelancerService;
        this.projectService = projectService;
    }

//    @GetMapping("recommendations/freelancer/{freelanceremailid}")
//    public ResponseEntity<?> recommendedFreelancers() {
//        List<Freelancers> freelancers=new ArrayList<>();
//        return new ResponseEntity<List<Freelancers>>(freelancers, HttpStatus.OK);
//    }
//
//    @GetMapping("recommendations/project/{projectid}")
//    public ResponseEntity<?> recommendedProjects() {
//        List<Projects> projects=new ArrayList<>();
//        return new ResponseEntity<List<Projects>>(projects, HttpStatus.OK);
//    }
//
//    @GetMapping("recommendations/project")
//    public ResponseEntity<?> trendingProjects() {
//        List<Projects> projects=new ArrayList<>();
//        return new ResponseEntity<List<Projects>>(projects, HttpStatus.OK);
//    }
//
//    @GetMapping("recommendations/freelancers")
//    public ResponseEntity<?> trendingFreelancers() {
//        List<Freelancers> freelancers=new ArrayList<>();
//        return new ResponseEntity<List<Freelancers>>(freelancers, HttpStatus.OK);
//    }

//    @PostMapping("/{freelanceremailId}")
//    public ResponseEntity<String> saverating(@PathVariable String freelanceremailId) {
//        ResponseEntity responseEntity;
//        userService.saveMovie(movie);
//        responseEntity = new ResponseEntity<String>("Succesfully add", HttpStatus.CREATED);
//        return responseEntity;
//    }

//    @GetMapping("/users")
//    public ResponseEntity<Iterable<Freelancers>> getAll() {
//        Iterable<Freelancers> allFreelancers = freelancerService.getAll();
//        return new ResponseEntity<Iterable<Freelancers>>(allFreelancers, HttpStatus.OK);
//    }


    @GetMapping("/recommendations/allfreelancer/Skill/{skillName}")
    public ResponseEntity<Iterable<Freelancers>> getAllFreelancers(@PathVariable String skillName) {
        Iterable<Freelancers> freelancers = freelancerService.getAllFreelancers(skillName);
        return new ResponseEntity<>(freelancers, HttpStatus.OK);
    }

//    @GetMapping("/recommendations/allProjects/Skill/{skillName}")
//    public ResponseEntity<Iterable<Projects>> getAllProjects(@PathVariable String skillName) {
//        Iterable<Projects> projects = projectService.getAllProjects(skillName);
//        return new ResponseEntity<>(projects, HttpStatus.OK);
//    }


//    @GetMapping("/recommendations/allfreelancer")
//    public ResponseEntity<Iterable<Freelancers>> getAllFreelancersDemo(){
//        return new ResponseEntity<>(freelancerService.getAll(),HttpStatus.OK);
//    }
//    @GetMapping("/allprojects")("/allfreelancers")
//    public Collection<Projects> getAllProjects(){
//        return projectService.getAllProjects();
//    }




    @GetMapping("/recommendations/allProjects/Skill/{skillName}")
    public ResponseEntity<Iterable<Projects>> getAllProjects(@PathVariable List<String> skillName) {
        List<Projects> projects=null;
        for (String param : skillName) {
            System.out.println(param);
            projects=projectService.getAllProjects(param);
            System.out.println(projects);
        }
//        String param =skillName;
//            System.out.println(param);
//            projects.addAll(projectService.getAllProjects(param));
//
//            System.out.println(projects);

        return new ResponseEntity<>(projects, HttpStatus.OK);
    }
//...............................................
//    @PostMapping("/freelancer")
//    public ResponseEntity<?> addFreelancer(@RequestBody Freelancers freelancer) {
//        String emailId =freelancer.getEmailId();
//        System.out.println(emailId);
//        Iterable<Freelancers> addfreelancer = freelancerService.saveFreelancers(emailId);
//        return new ResponseEntity<>(addfreelancer,HttpStatus.OK);
//
//    }

}
