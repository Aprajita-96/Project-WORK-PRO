package com.stackroute.RecommendationService.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.neo4j.ogm.annotation.GraphId;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Relationship;
import org.springframework.data.neo4j.annotation.QueryResult;

import java.util.List;
@Data
@NoArgsConstructor
@AllArgsConstructor
@NodeEntity(label = "Freelancers")
@Builder
@QueryResult
public class Freelancers {
    @Id
    private String EmailId;

    @Relationship(type = "hasSkill",direction = Relationship.OUTGOING)
    List<Skill> skills;
}
